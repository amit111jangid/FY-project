<!-- Footer Section Starts -->
<div class="footer">
            <div class="wrapper">
                <p class="text-center">2023 All rights reserved, Yummy Tummy. Developed By - PyHakers Team <a href="#"></a></p>
            </div>
        </div>
        <!-- Footer Section Ends -->

    </body>
</html>